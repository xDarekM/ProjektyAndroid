package pl.atk.szkolenietest;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

/**
 * Created by Tomasz on 04.11.2017.
 */

public class RepoViewHolder {
    //todo 5: zaimplementuj viewholder


    //todo 9: dodaj funkcjonalność klikania na viewholder
    //todo 10.2: po kliknięciu prześlij do drugiej aktywności obiekt repo i wystartuj aktywnosc
}
